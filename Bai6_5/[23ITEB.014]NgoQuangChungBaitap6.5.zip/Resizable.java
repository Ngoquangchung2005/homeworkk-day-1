package Bai6_5;

public interface Resizable {
	 public void resize(int percent);
	
}
